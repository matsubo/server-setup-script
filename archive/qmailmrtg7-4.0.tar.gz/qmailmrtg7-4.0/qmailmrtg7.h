int BigTodo=1;
int ConfSplit=93;
